import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consul',
  templateUrl: './consul.component.html',
  styleUrls: ['./consul.component.css']
})
export class ConsulComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
