import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quien',
  templateUrl: './quien.component.html',
  styleUrls: ['./quien.component.css']
})
export class QuienComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
