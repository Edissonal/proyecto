import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comu',
  templateUrl: './comu.component.html',
  styleUrls: ['./comu.component.css']
})
export class ComuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
