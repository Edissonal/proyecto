import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infra',
  templateUrl: './infra.component.html',
  styleUrls: ['./infra.component.css']
})
export class InfraComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
